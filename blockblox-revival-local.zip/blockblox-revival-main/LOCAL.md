# Локальный режим (offline-профиль)

Вкладки: **Play · Profile · Avatar**. Оформление — светлое, в стиле Roblox.

- **Profile** — 3D-аватар, круглая аватарка (рендерится из аватара), имя + галочка + значок Plus/Pro, Friends/Followers/Following, bio,
  «Edit appearance», «Edit profile» (ник, робуксы, цифры, bio, бейджи), «Currently Wearing».
- **Avatar** — Marketplace (каталог Roblox, тап = примерить, «Get & wear») и Customize (цвета тела, добавить по ID, Currently wearing, Closet).

Всё хранится в SharedPreferences на телефоне (`LocalStore.kt`). Интернет нужен для каталога, превью и текстур одежды.
