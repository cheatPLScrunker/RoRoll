package org.libreblox.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Roblox asset type ids -> wearable slot / attachment point. */
object Wear {
    const val NONE = 0
    const val SHIRT = 1
    const val PANTS = 2
    const val TSHIRT = 3
    const val FACE = 4
    const val ACC = 5

    const val A_HEAD = 0
    const val A_FACE = 1
    const val A_NECK = 2
    const val A_SHOULDER = 3
    const val A_FRONT = 4
    const val A_BACK = 5
    const val A_WAIST = 6
    const val A_FEET = 7
    const val A_TORSO = 8
    const val A_LEGS = 9

    fun slot(assetType: Int): Int = when (assetType) {
        11 -> SHIRT
        12 -> PANTS
        2 -> TSHIRT
        18 -> FACE
        8, 41, 42, 43, 44, 45, 46, 47, 64, 65, 66, 67, 68, 69, 70, 71, 72 -> ACC
        else -> NONE
    }

    fun attach(assetType: Int): Int = when (assetType) {
        8, 41 -> A_HEAD
        42 -> A_FACE
        43 -> A_NECK
        44 -> A_SHOULDER
        45 -> A_FRONT
        46 -> A_BACK
        47 -> A_WAIST
        70, 71 -> A_FEET
        64, 65, 67, 68 -> A_TORSO
        66, 69, 72 -> A_LEGS
        else -> A_HEAD
    }
}

class HeadMesh(val pos: FloatArray, val nrm: FloatArray, val tris: IntArray)

/** Loads the R6 head mesh (Roblox mesh format v2.00) from assets/avatar/head.mesh. Null if missing -> box head. */
object AvatarMeshes {
    private var cached: HeadMesh? = null
    private var tried = false

    fun head(ctx: Context): HeadMesh? {
        if (tried) return cached
        tried = true
        cached = try {
            parse(ctx.assets.open("avatar/head.mesh").use { it.readBytes() })
        } catch (_: Exception) {
            null
        }
        return cached
    }

    private fun parse(b: ByteArray): HeadMesh {
        var p = 0
        while (b[p] != 10.toByte()) p++
        p++
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val hdr = bb.getShort(p).toInt() and 0xFFFF
        val vs = bb.get(p + 2).toInt() and 0xFF
        val fs = bb.get(p + 3).toInt() and 0xFF
        val nv = bb.getInt(p + 4)
        val nf = bb.getInt(p + 8)
        val v0 = p + hdr
        val pos = FloatArray(nv * 3)
        val nrm = FloatArray(nv * 3)
        for (i in 0 until nv) {
            val o = v0 + i * vs
            for (k in 0..2) {
                pos[i * 3 + k] = bb.getFloat(o + 4 * k)
                nrm[i * 3 + k] = bb.getFloat(o + 12 + 4 * k)
            }
        }
        val f0 = v0 + nv * vs
        val tris = IntArray(nf * 3)
        for (i in 0 until nf) for (k in 0..2) tris[i * 3 + k] = bb.getInt(f0 + i * fs + 4 * k)
        return HeadMesh(pos, nrm, tris)
    }
}

class Sprite(val bmp: Bitmap, val attach: Int)

/** colors: head, torso, right arm, left arm, right leg, left leg (ARGB). */
class Outfit(
    val colors: IntArray,
    val shirt: Bitmap?,
    val pants: Bitmap?,
    val tshirt: Bitmap?,
    val face: Bitmap?,
    val sprites: List<Sprite>,
)

/**
 * Tiny software "3D" renderer for the classic R6 body: textured boxes (real classic shirt/pants
 * template layout, 585x559) + the real head mesh. Orthographic camera -> exact affine texturing.
 */
object AvatarRenderer {
    private fun r(x: Int, y: Int, w: Int, h: Int) = floatArrayOf(x.toFloat(), y.toFloat(), w.toFloat(), h.toFloat())

    private val TORSO = mapOf(
        'F' to r(231, 74, 128, 128), 'B' to r(427, 74, 128, 128),
        'R' to r(165, 74, 64, 128), 'L' to r(361, 74, 64, 128),
        'T' to r(231, 8, 128, 64), 'D' to r(231, 204, 128, 64),
    )
    /** Right arm / right leg strip. */
    private val STRIP_A = mapOf(
        'L' to r(19, 355, 64, 128), 'B' to r(85, 355, 64, 128),
        'R' to r(151, 355, 64, 128), 'F' to r(217, 355, 64, 128),
        'T' to r(217, 289, 64, 64), 'D' to r(217, 485, 64, 64),
    )
    /** Left arm / left leg strip. */
    private val STRIP_B = mapOf(
        'F' to r(308, 355, 64, 128), 'L' to r(374, 355, 64, 128),
        'B' to r(440, 355, 64, 128), 'R' to r(506, 355, 64, 128),
        'T' to r(308, 289, 64, 64), 'D' to r(308, 485, 64, 64),
    )

    private class Part(
        val cx: Float, val cy: Float, val cz: Float,
        val hx: Float, val hy: Float, val hz: Float,
        val colorIdx: Int, val rects: Map<Char, FloatArray>,
        val shirt: Boolean, val pants: Boolean,
    )

    private val PARTS = listOf(
        Part(0f, 0f, 0f, 1f, 1f, 0.5f, 1, TORSO, true, true),
        Part(1.5f, 0f, 0f, 0.5f, 1f, 0.5f, 2, STRIP_A, true, false),
        Part(-1.5f, 0f, 0f, 0.5f, 1f, 0.5f, 3, STRIP_B, true, false),
        Part(0.5f, -2f, 0f, 0.5f, 1f, 0.5f, 4, STRIP_A, false, true),
        Part(-0.5f, -2f, 0f, 0.5f, 1f, 0.5f, 5, STRIP_B, false, true),
    )
    private val BOX_HEAD = Part(0f, 1.5f, 0f, 0.6f, 0.6f, 0.6f, 0, emptyMap(), false, false)

    private val NORMALS = mapOf(
        'F' to floatArrayOf(0f, 0f, -1f), 'B' to floatArrayOf(0f, 0f, 1f),
        'R' to floatArrayOf(1f, 0f, 0f), 'L' to floatArrayOf(-1f, 0f, 0f),
        'T' to floatArrayOf(0f, 1f, 0f), 'D' to floatArrayOf(0f, -1f, 0f),
    )

    /** Corners p0 (texture top-left), p1 (top-right), p2 (bottom-left) as seen from outside the face. */
    private fun corners(ch: Char, p: Part): FloatArray {
        val (x, y, z) = Triple(p.cx, p.cy, p.cz)
        val (a, b, c) = Triple(p.hx, p.hy, p.hz)
        return when (ch) {
            'F' -> floatArrayOf(x + a, y + b, z - c, x - a, y + b, z - c, x + a, y - b, z - c)
            'B' -> floatArrayOf(x - a, y + b, z + c, x + a, y + b, z + c, x - a, y - b, z + c)
            'R' -> floatArrayOf(x + a, y + b, z + c, x + a, y + b, z - c, x + a, y - b, z + c)
            'L' -> floatArrayOf(x - a, y + b, z - c, x - a, y + b, z + c, x - a, y - b, z - c)
            'T' -> floatArrayOf(x + a, y + b, z + c, x - a, y + b, z + c, x + a, y + b, z - c)
            else -> floatArrayOf(x + a, y - b, z - c, x - a, y - b, z - c, x + a, y - b, z + c)
        }
    }

    private class Cam(rad: Double, val scale: Float, val cx: Float, val cy: Float) {
        val cs = cos(rad).toFloat()
        val sn = sin(rad).toFloat()
        val pitch = (12.0 * PI / 180.0)
        val cp = cos(pitch).toFloat()
        val sp = sin(pitch).toFloat()

        /** out = screenX, screenY, depth (bigger = farther). */
        fun proj(x: Float, y: Float, z: Float, out: FloatArray) {
            val xr = x * cs + z * sn
            val zr = -x * sn + z * cs
            out[0] = cx - xr * scale
            out[1] = cy - (y * cp + zr * sp + 0.45f) * scale
            out[2] = zr * cp - y * sp
        }

        /** Returns (ny, nz) of a rotated normal; visible when nz < 0. */
        fun normal(nx: Float, ny: Float, nz: Float): FloatArray {
            val nzr = -nx * sn + nz * cs
            return floatArrayOf(ny * cp + nzr * sp, nzr * cp - ny * sp)
        }
    }

    private class Item(val depth: Float, val draw: (Canvas) -> Unit)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL_AND_STROKE; strokeWidth = 1.2f }
    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.BLACK }

    private fun shadeOf(ny: Float, nz: Float) = (0.62f + 0.30f * (-nz) + 0.12f * ny).coerceIn(0.4f, 1f)

    /** Draws a bitmap region [rect] (template px) onto the projected parallelogram p0,p1,p2. */
    private fun drawTex(c: Canvas, clip: Path, bmp: Bitmap, rect: FloatArray?, q: FloatArray, alpha: Int = 255) {
        val sw = bmp.width / 585f
        val sh = bmp.height / 559f
        val src = if (rect == null) {
            floatArrayOf(0f, 0f, bmp.width.toFloat(), 0f, 0f, bmp.height.toFloat())
        } else {
            val l = rect[0] * sw; val t = rect[1] * sh; val w = rect[2] * sw; val h = rect[3] * sh
            floatArrayOf(l, t, l + w, t, l, t + h)
        }
        val m = Matrix()
        if (!m.setPolyToPoly(src, 0, floatArrayOf(q[0], q[1], q[2], q[3], q[4], q[5]), 0, 3)) return
        bmpPaint.alpha = alpha
        c.save()
        c.clipPath(clip)
        c.concat(m)
        c.drawBitmap(bmp, 0f, 0f, bmpPaint)
        c.restore()
    }

    fun render(c: Canvas, w: Float, h: Float, yawDeg: Float, o: Outfit, head: HeadMesh?) {
        val cam = Cam(yawDeg * PI / 180.0, min(w / 4.6f, h / 5.9f), w / 2f, h / 2f)
        val items = ArrayList<Item>()
        val tmp = FloatArray(3)

        // ---- box parts
        val boxes = if (head == null) PARTS + BOX_HEAD else PARTS
        for (part in boxes) {
            for ((ch, n) in NORMALS) {
                val nn = cam.normal(n[0], n[1], n[2])
                if (nn[1] >= 0f) continue
                val cr = corners(ch, part)
                val q = FloatArray(6)
                var depth = 0f
                for (i in 0..2) {
                    cam.proj(cr[i * 3], cr[i * 3 + 1], cr[i * 3 + 2], tmp)
                    q[i * 2] = tmp[0]; q[i * 2 + 1] = tmp[1]
                    depth += tmp[2]
                }
                val p3x = q[2] + q[4] - q[0]
                val p3y = q[3] + q[5] - q[1]
                // 4th corner depth ~ average of the opposite corners
                cam.proj(cr[3] + cr[6] - cr[0], cr[4] + cr[7] - cr[1], cr[5] + cr[8] - cr[2], tmp)
                depth = (depth + tmp[2]) / 4f
                val shade = shadeOf(nn[0], nn[1])
                val base = o.colors[part.colorIdx]
                val rect = part.rects[ch]
                items += Item(depth) { cv ->
                    val path = Path().apply {
                        moveTo(q[0], q[1]); lineTo(q[2], q[3]); lineTo(p3x, p3y); lineTo(q[4], q[5]); close()
                    }
                    fill.color = base
                    cv.drawPath(path, fill)
                    if (rect != null) {
                        if (part.pants && o.pants != null) drawTex(cv, path, o.pants, rect, q)
                        if (part.shirt && o.shirt != null) drawTex(cv, path, o.shirt, rect, q)
                        if (part === PARTS[0] && ch == 'F' && o.tshirt != null) drawTex(cv, path, o.tshirt, null, q)
                    }
                    shadePaint.color = Color.argb(((1f - shade) * 255).toInt(), 0, 0, 0)
                    cv.drawPath(path, shadePaint)
                }
            }
        }

        // ---- real head mesh
        if (head != null) {
            cam.proj(0f, 1.5f, 0f, tmp)
            val headDepth = tmp[2]
            items += Item(headDepth) { cv -> drawHead(cv, cam, head, o) }
        }

        // ---- accessory sprites (camera-facing thumbnails)
        for (s in o.sprites) {
            val a = anchor(s.attach)
            cam.proj(a[0], a[1], a[2], tmp)
            val sx = tmp[0]; val sy = tmp[1]
            val d = tmp[2] + a[4]
            val size = a[3] * cam.scale
            items += Item(d) { cv ->
                bmpPaint.alpha = 255
                val ar = s.bmp.width.toFloat() / s.bmp.height
                val dw = if (ar >= 1f) size else size * ar
                val dh = if (ar >= 1f) size / ar else size
                cv.drawBitmap(s.bmp, null, RectF(sx - dw / 2, sy - dh / 2, sx + dw / 2, sy + dh / 2), bmpPaint)
            }
        }

        items.sortByDescending { it.depth }
        for (it in items) it.draw(c)
    }

    /** x, y, z, size(studs), depth bias */
    private fun anchor(a: Int): FloatArray = when (a) {
        Wear.A_HEAD -> floatArrayOf(0f, 2.0f, 0f, 1.7f, -0.9f)
        Wear.A_FACE -> floatArrayOf(0f, 1.5f, -0.7f, 1.4f, -0.9f)
        Wear.A_NECK -> floatArrayOf(0f, 1.05f, -0.3f, 1.2f, -0.7f)
        Wear.A_SHOULDER -> floatArrayOf(0f, 1.0f, 0f, 2.6f, -0.2f)
        Wear.A_FRONT -> floatArrayOf(0f, 0.2f, -0.75f, 1.5f, -0.7f)
        Wear.A_BACK -> floatArrayOf(0f, 0.3f, 0.75f, 2.0f, 0f)
        Wear.A_WAIST -> floatArrayOf(0f, -1.0f, -0.1f, 2.4f, -0.3f)
        Wear.A_FEET -> floatArrayOf(0f, -3.4f, -0.2f, 2.4f, -0.5f)
        Wear.A_TORSO -> floatArrayOf(0f, 0.1f, -0.2f, 2.6f, -0.6f)
        else -> floatArrayOf(0f, -2.0f, -0.2f, 2.2f, -0.6f)
    }

    private fun drawHead(c: Canvas, cam: Cam, m: HeadMesh, o: Outfit) {
        val nv = m.pos.size / 3
        val sx = FloatArray(nv); val sy = FloatArray(nv); val sd = FloatArray(nv)
        val shade = FloatArray(nv); val vis = FloatArray(nv)
        val t = FloatArray(3)
        for (i in 0 until nv) {
            cam.proj(m.pos[i * 3], m.pos[i * 3 + 1] + 1.5f, m.pos[i * 3 + 2], t)
            sx[i] = t[0]; sy[i] = t[1]; sd[i] = t[2]
            val nn = cam.normal(m.nrm[i * 3], m.nrm[i * 3 + 1], m.nrm[i * 3 + 2])
            vis[i] = nn[1]
            shade[i] = shadeOf(nn[0], nn[1])
        }
        val nt = m.tris.size / 3
        val order = (0 until nt).filter { k ->
            val a = m.tris[k * 3]; val b = m.tris[k * 3 + 1]; val d = m.tris[k * 3 + 2]
            (vis[a] + vis[b] + vis[d]) / 3f < 0.05f
        }.sortedByDescending { k ->
            (sd[m.tris[k * 3]] + sd[m.tris[k * 3 + 1]] + sd[m.tris[k * 3 + 2]])
        }
        val base = o.colors[0]
        val path = Path()
        for (k in order) {
            val a = m.tris[k * 3]; val b = m.tris[k * 3 + 1]; val d = m.tris[k * 3 + 2]
            val sh = (shade[a] + shade[b] + shade[d]) / 3f
            path.rewind()
            path.moveTo(sx[a], sy[a]); path.lineTo(sx[b], sy[b]); path.lineTo(sx[d], sy[d]); path.close()
            fill.color = Color.rgb(
                (Color.red(base) * sh).toInt(), (Color.green(base) * sh).toInt(), (Color.blue(base) * sh).toInt(),
            )
            c.drawPath(path, fill)
        }
        // ---- face decal on the front, faded out when turned away
        val fade = ((cam.cs - 0.25f) / 0.5f).coerceIn(0f, 1f)
        if (fade <= 0f) return
        val z = -0.6f
        val p = FloatArray(9)
        val pts = arrayOf(floatArrayOf(0.5f, 2.0f, z), floatArrayOf(-0.5f, 2.0f, z), floatArrayOf(0.5f, 1.0f, z))
        for (i in 0..2) {
            cam.proj(pts[i][0], pts[i][1], pts[i][2], t)
            p[i * 3] = t[0]; p[i * 3 + 1] = t[1]
        }
        val q = floatArrayOf(p[0], p[1], p[3], p[4], p[6], p[7])
        val clip = Path().apply { addRect(-1e5f, -1e5f, 1e5f, 1e5f, Path.Direction.CW) }
        if (o.face != null) {
            drawTex(c, clip, o.face, null, q, (fade * 255).toInt())
        } else {
            val mx = Matrix()
            if (mx.setPolyToPoly(floatArrayOf(0f, 0f, 100f, 0f, 0f, 100f), 0, q, 0, 3)) {
                c.save()
                c.concat(mx)
                shadePaint.color = Color.argb((fade * 255).toInt(), 0, 0, 0)
                c.drawOval(RectF(29f, 30f, 39f, 48f), shadePaint)
                c.drawOval(RectF(61f, 30f, 71f, 48f), shadePaint)
                line.strokeWidth = 5f
                line.color = Color.argb((fade * 255).toInt(), 0, 0, 0)
                c.drawArc(RectF(26f, 36f, 74f, 78f), 25f, 130f, false, line)
                c.restore()
            }
        }
    }
}
