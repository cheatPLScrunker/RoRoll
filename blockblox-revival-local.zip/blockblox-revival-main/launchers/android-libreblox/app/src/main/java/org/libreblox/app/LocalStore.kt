package org.libreblox.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** One item from the Roblox catalog (asset or bundle). [price] null = off-sale. [assetType] 0 = unknown/bundle. */
data class CatItem(
    val id: Long,
    val name: String,
    val type: String,
    val price: Long?,
    val creator: String,
    val thumb: String?,
    val assetType: Int = 0,
)

/**
 * Fully local profile: nothing here is sent anywhere and no roblox.com login is involved.
 * Name, verified badge, Robux balance, owned items, worn items and body colors live in
 * SharedPreferences on the phone.
 */
object LocalStore {
    const val MAX_ROBUX = 9_999_999_999L

    /** Body color slots: 0 head, 1 torso, 2 right arm, 3 left arm, 4 right leg, 5 left leg. */
    private val DEFAULT_COLORS = intArrayOf(
        0xFFF5CD30.toInt(), 0xFF0D69AC.toInt(), 0xFFF5CD30.toInt(),
        0xFFF5CD30.toInt(), 0xFF287F47.toInt(), 0xFF287F47.toInt(),
    )

    private const val PREF = "revival_local"
    private lateinit var prefs: SharedPreferences
    private var ready = false

    var username by mutableStateOf("Player1")
        private set
    var displayName by mutableStateOf("Player1")
        private set
    var verified by mutableStateOf(true)
        private set
    var robux by mutableStateOf(10_000L)
        private set
    val owned = mutableStateListOf<CatItem>()
    /** Ids of owned items that are worn right now (saved). */
    val equipped = mutableStateListOf<Long>()
    /** Items being tried on from the catalog (not owned, not saved). */
    val tryOn = mutableStateListOf<CatItem>()
    val bodyColors = mutableStateListOf<Int>()

    fun init(ctx: Context) {
        if (ready) return
        prefs = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        username = prefs.getString("username", "Player1") ?: "Player1"
        displayName = prefs.getString("display", username) ?: username
        verified = prefs.getBoolean("verified", true)
        robux = prefs.getLong("robux", 10_000L).coerceIn(0, MAX_ROBUX)
        owned.clear()
        try {
            val arr = JSONArray(prefs.getString("owned", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                owned += CatItem(
                    id = o.optLong("id"),
                    name = o.optString("name"),
                    type = o.optString("type", "Asset"),
                    price = if (o.has("price")) o.optLong("price") else null,
                    creator = o.optString("creator"),
                    thumb = o.optString("thumb").ifEmpty { null },
                    assetType = o.optInt("assetType", 0),
                )
            }
        } catch (_: Exception) {
        }
        equipped.clear()
        prefs.getString("equipped", "")?.split(",")?.mapNotNull { it.trim().toLongOrNull() }
            ?.filter { id -> owned.any { it.id == id } }?.let { equipped.addAll(it) }
        bodyColors.clear()
        val saved = prefs.getString("colors", "")?.split(",")?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()
        bodyColors.addAll(if (saved.size == 6) saved else DEFAULT_COLORS.toList())
        ready = true
    }

    private fun saveOwned() {
        val arr = JSONArray()
        owned.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                .put("creator", it.creator).put("thumb", it.thumb ?: "").put("assetType", it.assetType)
            if (it.price != null) o.put("price", it.price)
            arr.put(o)
        }
        prefs.edit().putString("owned", arr.toString()).apply()
    }

    private fun saveEquipped() {
        prefs.edit().putString("equipped", equipped.joinToString(",")).apply()
    }

    private fun saveColors() {
        prefs.edit().putString("colors", bodyColors.joinToString(",")).apply()
    }

    fun setIdentity(user: String, display: String) {
        val u = user.trim().ifEmpty { "Player1" }.take(20)
        val d = display.trim().ifEmpty { u }.take(30)
        username = u
        displayName = d
        prefs.edit().putString("username", u).putString("display", d).apply()
    }

    fun setVerified(on: Boolean) {
        verified = on
        prefs.edit().putBoolean("verified", on).apply()
    }

    fun setRobux(v: Long) {
        robux = v.coerceIn(0, MAX_ROBUX)
        prefs.edit().putLong("robux", robux).apply()
    }

    fun addRobux(delta: Long) = setRobux(robux + delta)

    fun owns(id: Long) = owned.any { it.id == id }

    /** Takes an item for free (local only). */
    fun give(item: CatItem) {
        if (owns(item.id)) return
        owned.add(0, item)
        saveOwned()
    }

    /** Pays [CatItem.price] from the local balance. Returns false when there is not enough Robux. */
    fun buy(item: CatItem): Boolean {
        val p = item.price ?: return false
        if (owns(item.id)) return true
        if (robux < p) return false
        setRobux(robux - p)
        give(item)
        return true
    }

    fun remove(id: Long) {
        owned.removeAll { it.id == id }
        saveOwned()
        if (equipped.remove(id)) saveEquipped()
    }

    // ---------------------------------------------------------------- avatar

    fun isWearable(item: CatItem) = Wear.slot(item.assetType) != Wear.NONE

    fun isEquipped(id: Long) = equipped.contains(id)

    /** Wears an owned item; a new shirt/pants/T-shirt/face replaces the previous one. False if not wearable. */
    fun equip(item: CatItem): Boolean {
        if (!isWearable(item)) return false
        give(item)
        val slot = Wear.slot(item.assetType)
        if (slot != Wear.ACC) {
            equipped.removeAll { id -> owned.firstOrNull { it.id == id }?.let { Wear.slot(it.assetType) } == slot }
        }
        if (!equipped.contains(item.id)) equipped.add(item.id)
        tryOn.removeAll { it.id == item.id }
        saveEquipped()
        return true
    }

    fun unequip(id: Long) {
        if (equipped.remove(id)) saveEquipped()
    }

    fun toggleEquip(item: CatItem): Boolean {
        if (!isWearable(item)) return false
        if (isEquipped(item.id)) unequip(item.id) else equip(item)
        return true
    }

    fun isTryingOn(id: Long) = tryOn.any { it.id == id }

    /** Adds/removes an item in the fitting room. False if the item type cannot be worn. */
    fun toggleTryOn(item: CatItem): Boolean {
        if (!isWearable(item)) return false
        if (isTryingOn(item.id)) tryOn.removeAll { it.id == item.id } else tryOn.add(item)
        return true
    }

    fun clearTryOn() = tryOn.clear()

    fun takeOffAll() {
        equipped.clear()
        saveEquipped()
        tryOn.clear()
    }

    /** What the avatar wears right now: worn items, with fitting-room items replacing the same slot. */
    fun outfit(): List<CatItem> {
        val worn = equipped.mapNotNull { id -> owned.firstOrNull { it.id == id } }.toMutableList()
        for (t in tryOn) {
            val slot = Wear.slot(t.assetType)
            if (slot != Wear.ACC) worn.removeAll { Wear.slot(it.assetType) == slot }
            worn.removeAll { it.id == t.id }
            worn.add(t)
        }
        return worn
    }

    fun setBodyColor(index: Int, argb: Int) {
        if (index !in 0..5) return
        bodyColors[index] = argb
        saveColors()
    }

    fun setAllBodyColors(argb: Int) {
        for (i in 0..5) bodyColors[i] = argb
        saveColors()
    }

    fun resetColors() {
        for (i in 0..5) bodyColors[i] = DEFAULT_COLORS[i]
        saveColors()
    }

    fun resetAll() {
        owned.clear()
        saveOwned()
        takeOffAll()
        resetColors()
        setIdentity("Player1", "Player1")
        setVerified(true)
        setRobux(10_000L)
    }
}
