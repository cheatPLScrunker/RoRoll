package org.libreblox.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

val RbxBlue = Color(0xFF335FFF)
val RbxInk = Color(0xFF191919)
val RbxGrey = Color(0xFF6B6F7B)
val RbxPill = Color(0xFFE7E8EC)
val RbxCard = Color(0xFFE9EAEE)
val RbxField = Color(0xFFEDEDF1)

val RbxColors = lightColorScheme(
    primary = RbxBlue,
    onPrimary = Color.White,
    background = Color.White,
    onBackground = RbxInk,
    surface = Color.White,
    onSurface = RbxInk,
    surfaceVariant = RbxCard,
    onSurfaceVariant = RbxGrey,
    outline = Color(0xFFD0D2D8),
    secondaryContainer = Color(0xFFDDE3FF),
    surfaceContainer = Color.White,
)

/** 5600000 -> "5.6M", 55488 -> "55.5K". */
fun rbxShort(n: Long): String {
    fun t(v: Double) = String.format(Locale.US, "%.1f", v).removeSuffix(".0")
    return when {
        n >= 1_000_000 -> t(n / 1_000_000.0) + "M"
        n >= 1_000 -> t(n / 1_000.0) + "K"
        else -> n.toString()
    }
}

fun rbxFull(n: Long): String = String.format(Locale.US, "%,d", n)

/** Blue rounded-square verified tick. */
@Composable
fun RbxVerifiedBadge(s: Dp = 22.dp) {
    Canvas(Modifier.size(s)) {
        val w = size.width
        drawRoundRect(RbxBlue, cornerRadius = CornerRadius(w * 0.28f))
        val p = Path().apply {
            moveTo(w * 0.27f, w * 0.52f)
            lineTo(w * 0.44f, w * 0.68f)
            lineTo(w * 0.74f, w * 0.34f)
        }
        drawPath(p, Color.White, style = Stroke(width = w * 0.12f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Plus / Pro membership badge (outlined square glyph). */
@Composable
fun RbxPlanBadge(s: Dp = 24.dp) {
    Canvas(Modifier.size(s)) {
        val w = size.width
        drawRoundRect(RbxInk, topLeft = Offset(w * 0.08f, w * 0.08f), size = Size(w * 0.84f, w * 0.84f),
            cornerRadius = CornerRadius(w * 0.2f), style = Stroke(w * 0.1f))
        drawRoundRect(RbxInk, topLeft = Offset(w * 0.32f, w * 0.32f), size = Size(w * 0.36f, w * 0.36f),
            cornerRadius = CornerRadius(w * 0.08f), style = Stroke(w * 0.1f))
    }
}

/** Robux hexagon icon. */
@Composable
fun RobuxIcon(s: Dp = 20.dp, tint: Color = RbxInk) {
    Canvas(Modifier.size(s)) {
        val w = size.width
        val c = w / 2f
        fun hex(rad: Float): Path {
            val p = Path()
            for (i in 0..5) {
                val a = Math.toRadians(60.0 * i - 90.0)
                val x = c + (rad * cos(a)).toFloat()
                val y = c + (rad * sin(a)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
            return p
        }
        drawPath(hex(c * 0.9f), tint, style = Stroke(w * 0.12f, join = StrokeJoin.Round))
        drawPath(hex(c * 0.42f), tint, style = Stroke(w * 0.1f, join = StrokeJoin.Round))
    }
}

@Composable
fun RbxPrice(price: Long?, fontSize: TextUnit = 16.sp) {
    when (price) {
        null -> Text("Off sale", color = RbxGrey, fontSize = fontSize)
        0L -> Text("Free", color = RbxInk, fontSize = fontSize, fontWeight = FontWeight.Medium)
        else -> Row(verticalAlignment = Alignment.CenterVertically) {
            RobuxIcon(16.dp, RbxGrey)
            Spacer(Modifier.width(4.dp))
            Text(rbxFull(price), color = RbxGrey, fontSize = fontSize)
        }
    }
}

@Composable
fun RbxButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    height: Dp = 52.dp,
    fontSize: TextUnit = 18.sp,
) {
    Box(
        modifier.height(height).clip(RoundedCornerShape(14.dp))
            .background(if (primary) RbxBlue else RbxPill).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (primary) Color.White else RbxInk, fontSize = fontSize, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun RbxLabeledField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    number: Boolean = false,
    minLines: Int = 1,
) {
    Column(modifier) {
        Text(label, color = RbxGrey, fontSize = 14.sp, modifier = Modifier.padding(bottom = 4.dp))
        TextField(
            value = value,
            onValueChange = onChange,
            singleLine = minLines == 1,
            minLines = minLines,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = RbxField,
                unfocusedContainerColor = RbxField,
                disabledContainerColor = RbxField,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
                errorIndicatorColor = Color.Transparent,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** Marketplace-style square item card: grey tile, name, creator, price. */
@Composable
fun RbxItemCard(item: CatItem, width: Dp, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(width).clickable(onClick = onClick), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(RbxCard)
                .then(if (selected) Modifier.border(3.dp, RbxBlue, RoundedCornerShape(16.dp)) else Modifier),
        ) {
            AsyncImage(
                model = item.thumb, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().padding(10.dp),
            )
        }
        Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = RbxInk)
        if (item.creator.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.creator, fontSize = 15.sp, color = RbxGrey, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (item.creator.equals("Roblox", true)) {
                    Spacer(Modifier.width(4.dp))
                    RbxVerifiedBadge(14.dp)
                }
            }
        }
        RbxPrice(item.price)
    }
}
