package org.libreblox.app

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Loads textures for [items] in the background and builds what the renderer needs. */
@Composable
fun rememberOutfit(items: List<CatItem>): Outfit {
    LaunchedEffect(items.map { it.id }) {
        items.forEach { launch { AvatarTex.ensure(it) } }
    }
    fun texOf(slot: Int): Bitmap? =
        items.firstOrNull { Wear.slot(it.assetType) == slot }?.let { AvatarTex.tex[it.id] }
    return Outfit(
        colors = LocalStore.bodyColors.toIntArray(),
        shirt = texOf(Wear.SHIRT),
        pants = texOf(Wear.PANTS),
        tshirt = texOf(Wear.TSHIRT),
        face = texOf(Wear.FACE),
        sprites = items.filter { Wear.slot(it.assetType) == Wear.ACC }
            .mapNotNull { i -> AvatarTex.sprites[i.id]?.let { Sprite(it, Wear.attach(i.assetType)) } },
    )
}

// ================================================================== PROFILE

@Composable
fun LocalProfileScreen(onEditAppearance: () -> Unit) {
    val ctx = LocalContext.current
    val outfit = rememberOutfit(LocalStore.outfit())
    val head = remember { AvatarMeshes.head(ctx) }
    val headshot = remember(listOf(outfit.colors.toList(), outfit.shirt, outfit.pants, outfit.tshirt, outfit.face, outfit.sprites.map { it.bmp })) {
        AvatarRenderer.headshot(256, outfit, head)
    }
    var editing by remember { mutableStateOf(false) }
    val worn = LocalStore.equipped.mapNotNull { id -> LocalStore.owned.firstOrNull { it.id == id } }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth().height(380.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFFC4C6CB), Color(0xFFE9EAEC), Color.White))),
        ) {
            AvatarView(outfit, Modifier.fillMaxSize().padding(top = 28.dp), autoRotate = false, initialYaw = 0f)
        }
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Image(
                    headshot.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(96.dp).clip(CircleShape),
                )
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            LocalStore.displayName, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RbxInk,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                        )
                        if (LocalStore.verified) {
                            Spacer(Modifier.width(8.dp))
                            RbxVerifiedBadge(26.dp)
                        }
                        if (LocalStore.plan > 0) {
                            Spacer(Modifier.width(8.dp))
                            RbxPlanBadge(26.dp)
                        }
                    }
                    Text("@${LocalStore.username}", fontSize = 18.sp, color = RbxGrey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "${rbxShort(LocalStore.friends)} Friends",
                    "${rbxShort(LocalStore.followers)} Followers",
                    "${rbxShort(LocalStore.following)} Following",
                ).forEach {
                    Text(
                        it, fontSize = 17.sp, color = RbxInk,
                        modifier = Modifier.clip(RoundedCornerShape(24.dp)).background(RbxPill).padding(horizontal = 18.dp, vertical = 12.dp),
                    )
                }
            }
            if (LocalStore.bio.isNotBlank()) Text(LocalStore.bio, fontSize = 18.sp, color = RbxInk)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RbxButton("Edit appearance", onEditAppearance, Modifier.weight(1.4f), primary = true)
                RbxButton("Edit profile", { editing = true }, Modifier.weight(1f))
            }
            Text("Currently Wearing", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RbxInk)
            if (worn.isEmpty()) {
                Text("Nothing yet. Open Edit appearance to wear items.", color = RbxGrey, fontSize = 16.sp)
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    worn.forEach { RbxItemCard(it, 150.dp, selected = false, onClick = {}) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (editing) RbxEditProfileDialog { editing = false }
}

@Composable
private fun RbxEditProfileDialog(onDismiss: () -> Unit) {
    var user by remember { mutableStateOf(LocalStore.username) }
    var disp by remember { mutableStateOf(LocalStore.displayName) }
    var robux by remember { mutableStateOf(LocalStore.robux.toString()) }
    var friends by remember { mutableStateOf(LocalStore.friends.toString()) }
    var followers by remember { mutableStateOf(LocalStore.followers.toString()) }
    var following by remember { mutableStateOf(LocalStore.following.toString()) }
    var bio by remember { mutableStateOf(LocalStore.bio) }
    var verified by remember { mutableStateOf(LocalStore.verified) }
    var plan by remember { mutableIntStateOf(LocalStore.plan) }
    fun num(s: String) = s.filter { it.isDigit() }.take(10).toLongOrNull() ?: 0L

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp), color = Color.White,
            modifier = Modifier.fillMaxWidth().padding(16.dp).heightIn(max = 680.dp),
        ) {
            Column {
                Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Edit — Profile", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = RbxInk, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }
                HorizontalDivider()
                Column(
                    Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Text("Account", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        RbxLabeledField("Username", user, { user = it.take(20) }, Modifier.weight(1f))
                        RbxLabeledField("Display name", disp, { disp = it.take(30) }, Modifier.weight(1f))
                    }
                    RbxLabeledField("Robux", robux, { robux = it.filter(Char::isDigit).take(10) }, number = true)
                    Text("Friends, followers & following", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RbxLabeledField("Friends", friends, { friends = it.filter(Char::isDigit).take(9) }, Modifier.weight(1f), number = true)
                        RbxLabeledField("Followers", followers, { followers = it.filter(Char::isDigit).take(9) }, Modifier.weight(1f), number = true)
                        RbxLabeledField("Following", following, { following = it.filter(Char::isDigit).take(9) }, Modifier.weight(1f), number = true)
                    }
                    Text("Bio", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
                    RbxLabeledField("About (up to 1,000 characters)", bio, { bio = it.take(1000) }, minLines = 5)
                    Text("Badges", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = verified, onCheckedChange = { verified = it })
                        Text("Verified (shown first, right after your name)", fontSize = 16.sp, color = RbxInk)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf("No badge", "Plus", "Pro").forEachIndexed { i, t ->
                            RbxButton(t, { plan = i }, Modifier.weight(1f), primary = plan == i, height = 48.dp, fontSize = 17.sp)
                        }
                    }
                    RbxButton("Save", {
                        LocalStore.setIdentity(user, disp)
                        LocalStore.changeRobux(num(robux))
                        LocalStore.updateSocial(bio, num(friends), num(followers), num(following))
                        LocalStore.changeVerified(verified)
                        LocalStore.updatePlan(plan)
                        onDismiss()
                    }, Modifier.fillMaxWidth(), primary = true)
                }
            }
        }
    }
}

// ================================================================== AVATAR EDITOR

private val PALETTE: List<Long> = listOf(
    0xFFF5CD30, 0xFFF2F3F3, 0xFFA3A2A5, 0xFF635F62, 0xFF1B2A35, 0xFFC4281C, 0xFFDA8541, 0xFFE9A5C6,
    0xFF0D69AC, 0xFF98C2DB, 0xFF287F47, 0xFF4B974B, 0xFF6B327C, 0xFFF2C28D, 0xFFCC8E69, 0xFF7C5C46,
)
private val PART_NAMES = listOf("All body", "Head", "Torso", "Arms", "Legs")
private val CATS = listOf("All" to 1, "Accessories" to 11, "Clothing" to 3, "Body" to 4, "Animations" to 12, "Gear" to 5)

@Composable
fun LocalAvatarScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val outfit = rememberOutfit(LocalStore.outfit())
    var mode by remember { mutableIntStateOf(0) }
    var cat by remember { mutableIntStateOf(1) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var res by remember { mutableStateOf<Load<List<CatItem>>>(Load.Idle) }

    LaunchedEffect(cat, query, retry) {
        res = Load.Busy
        res = try {
            Load.Ok(Api.catalogItems(query, cat))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Load.Err(e.message ?: e.toString())
        }
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    fun tap(item: CatItem) {
        when {
            !LocalStore.isWearable(item) -> { LocalStore.give(item); toast("Added to your closet") }
            LocalStore.owns(item.id) -> LocalStore.toggleEquip(item)
            else -> LocalStore.toggleTryOn(item)
        }
    }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        Box(
            Modifier.fillMaxWidth().weight(0.46f)
                .background(Brush.verticalGradient(listOf(Color(0xFFD5D6DA), Color(0xFFF1F1F3)))),
        ) {
            AvatarView(outfit, Modifier.fillMaxSize().padding(top = 56.dp), autoRotate = false, initialYaw = 0f)
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Spacer(Modifier.weight(1f))
                Row(Modifier.clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = 0.75f)).padding(4.dp)) {
                    listOf("Marketplace", "Customize").forEachIndexed { i, t ->
                        Text(
                            t, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = RbxInk,
                            modifier = Modifier.clip(RoundedCornerShape(20.dp))
                                .background(if (mode == i) Color(0xFFDCE0EE) else Color.Transparent)
                                .clickable { mode = i }.padding(horizontal = 14.dp, vertical = 8.dp),
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { mode = 0; searching = !searching }) { Icon(Icons.Default.Search, contentDescription = "Search") }
            }
            Row(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 60.dp, end = 16.dp)
                    .clip(RoundedCornerShape(24.dp)).background(Color.White).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RobuxIcon(22.dp, RbxInk)
                Spacer(Modifier.width(8.dp))
                Text(rbxShort(LocalStore.robux), fontSize = 18.sp, fontWeight = FontWeight.Medium, color = RbxInk)
            }
            if (LocalStore.tryOn.isNotEmpty()) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(20.dp)).background(Color.White)
                        .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Trying on ${LocalStore.tryOn.size}", fontSize = 16.sp, color = RbxInk)
                    Spacer(Modifier.width(12.dp))
                    RbxButton("Get & wear", {
                        LocalStore.tryOn.toList().forEach { LocalStore.equip(it) }
                        toast("Added to your closet and worn")
                    }, primary = true, height = 40.dp, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 2.dp))
                    Spacer(Modifier.width(6.dp))
                    RbxButton("Clear", { LocalStore.clearTryOn() }, height = 40.dp, fontSize = 15.sp)
                }
            }
        }
        Surface(
            Modifier.fillMaxWidth().weight(0.54f),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), color = Color.White, shadowElevation = 8.dp,
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                if (mode == 0) {
                    MarketSheet(
                        cat = cat, onCat = { cat = it }, searching = searching, query = query,
                        onQuery = { query = it }, res = res, onRetry = { retry++ }, onTap = ::tap,
                    )
                } else {
                    CustomizeSheet(::toast)
                }
            }
        }
    }
}

@Composable
private fun MarketSheet(
    cat: Int, onCat: (Int) -> Unit, searching: Boolean, query: String, onQuery: (String) -> Unit,
    res: Load<List<CatItem>>, onRetry: () -> Unit, onTap: (CatItem) -> Unit,
) {
    var draft by remember { mutableStateOf(query) }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
        CATS.forEach { (name, id) ->
            Column(Modifier.clickable { onCat(id) }) {
                Text(name, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = if (cat == id) RbxInk else RbxGrey)
                Box(Modifier.padding(top = 6.dp).height(2.dp).fillMaxWidth().background(if (cat == id) RbxInk else Color.Transparent))
            }
        }
    }
    if (searching) {
        TextField(
            value = draft, onValueChange = { draft = it }, singleLine = true,
            placeholder = { Text("Search the marketplace") },
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onQuery(draft.trim()) }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = RbxField, unfocusedContainerColor = RbxField,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
        )
    }
    Text(
        if (query.isBlank()) "Recommended For You" else "Results for “$query”",
        fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RbxInk, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
    )
    when (res) {
        Load.Idle, Load.Busy -> Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        is Load.Err -> Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Couldn't load the marketplace", fontWeight = FontWeight.Medium, color = RbxInk)
            Text(res.msg, fontSize = 13.sp, color = RbxGrey)
            RbxButton("Retry", onRetry, Modifier.fillMaxWidth(), height = 44.dp)
        }
        is Load.Ok -> if (res.v.isEmpty()) {
            Text("Nothing found", color = RbxGrey, modifier = Modifier.padding(20.dp))
        } else {
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(res.v) { item ->
                    RbxItemCard(
                        item, 150.dp,
                        selected = LocalStore.isTryingOn(item.id) || LocalStore.isEquipped(item.id),
                        onClick = { onTap(item) },
                    )
                }
            }
        }
    }
    Text(
        "Tap an item to try it on. “Get & wear” keeps it in your closet.",
        fontSize = 13.sp, color = RbxGrey, modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
    )
}

@Composable
private fun CustomizeSheet(toast: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var part by remember { mutableIntStateOf(0) }
    var idText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val outfitItems = LocalStore.outfit()
    val closet = LocalStore.owned.filter { !LocalStore.isEquipped(it.id) }

    fun applyColor(argb: Int) {
        when (part) {
            0 -> LocalStore.setAllBodyColors(argb)
            1 -> LocalStore.setBodyColor(0, argb)
            2 -> LocalStore.setBodyColor(1, argb)
            3 -> { LocalStore.setBodyColor(2, argb); LocalStore.setBodyColor(3, argb) }
            else -> { LocalStore.setBodyColor(4, argb); LocalStore.setBodyColor(5, argb) }
        }
    }

    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Body colors", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PART_NAMES.forEachIndexed { i, n ->
                Text(
                    n, fontSize = 15.sp, color = if (part == i) Color.White else RbxInk,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (part == i) RbxBlue else RbxPill)
                        .clickable { part = i }.padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PALETTE.forEach { c ->
                Box(Modifier.size(38.dp).clip(CircleShape).background(Color(c)).border(1.dp, Color(0xFFD0D2D8), CircleShape).clickable { applyColor(c.toInt()) })
            }
        }
        HorizontalDivider()
        Text("Avatar", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
        Text("Enter the ID of any Roblox item (the number in its catalog URL). It will be worn by your avatar.", fontSize = 15.sp, color = RbxGrey)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = idText, onValueChange = { idText = it.filter(Char::isDigit).take(14) }, singleLine = true,
                placeholder = { Text("Item ID, e.g. 1716504") }, shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = RbxField, unfocusedContainerColor = RbxField,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.weight(1f),
            )
            RbxButton(if (busy) "…" else "Add & wear", {
                val id = idText.toLongOrNull()
                if (id == null || busy) return@RbxButton
                busy = true
                scope.launch {
                    try {
                        val item = Api.assetDetails(id)
                        if (LocalStore.equip(item)) {
                            toast("Added: ${item.name}")
                        } else {
                            LocalStore.give(item)
                            toast("Added to closet (this type can't be worn yet)")
                        }
                        idText = ""
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        toast("Couldn't find that item")
                    } finally {
                        busy = false
                    }
                }
            }, primary = true, height = 52.dp, fontSize = 16.sp, modifier = Modifier.width(130.dp))
        }
        Text("Currently wearing", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
        if (outfitItems.isEmpty()) Text("Nothing yet.", color = RbxGrey)
        outfitItems.forEach { item ->
            val trying = LocalStore.isTryingOn(item.id)
            RbxItemRow(
                item,
                sub = AvatarTex.failed[item.id]?.let { "Texture failed: $it" } ?: if (trying) "Trying on" else item.id.toString(),
                button = "Take off",
            ) { if (trying) LocalStore.toggleTryOn(item) else LocalStore.unequip(item.id) }
        }
        HorizontalDivider()
        Text("Closet", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RbxInk)
        Text("Every item you took off stays here. Wear it again anytime.", fontSize = 15.sp, color = RbxGrey)
        if (closet.isEmpty()) Text("Empty.", color = RbxGrey)
        closet.forEach { item ->
            RbxItemRow(item, sub = item.id.toString(), button = if (LocalStore.isWearable(item)) "Wear" else "Remove") {
                if (LocalStore.isWearable(item)) LocalStore.equip(item) else LocalStore.remove(item.id)
            }
        }
    }
}

@Composable
private fun RbxItemRow(item: CatItem, sub: String, button: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(12.dp)).background(RbxCard)) {
            AsyncImage(model = item.thumb, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(6.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = RbxInk, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 14.sp, color = RbxGrey, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        RbxButton(button, onClick, height = 42.dp, fontSize = 15.sp, modifier = Modifier.width(96.dp))
    }
}
