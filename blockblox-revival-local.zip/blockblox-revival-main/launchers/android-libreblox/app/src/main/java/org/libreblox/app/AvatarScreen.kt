package org.libreblox.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Downloads and caches clothing textures / accessory sprites for worn items. */
object AvatarTex {
    val tex = mutableStateMapOf<Long, Bitmap>()
    val sprites = mutableStateMapOf<Long, Bitmap>()
    val failed = mutableStateMapOf<Long, String>()
    private val busy = HashSet<Long>()

    suspend fun ensure(item: CatItem) {
        val id = item.id
        val slot = Wear.slot(item.assetType)
        if (slot == Wear.NONE) return
        if (tex.containsKey(id) || sprites.containsKey(id) || !busy.add(id)) return
        try {
            if (slot == Wear.ACC) {
                val url = item.thumb ?: throw IllegalStateException("нет превью")
                val b = download(url)
                BitmapFactory.decodeByteArray(b, 0, b.size)?.let { sprites[id] = it }
            } else {
                val bmp = loadBitmap(id, 0) ?: throw IllegalStateException("текстура не найдена")
                tex[id] = bmp
            }
            failed.remove(id)
        } catch (e: Exception) {
            failed[id] = e.message ?: e.toString()
        } finally {
            busy.remove(id)
        }
    }

    private suspend fun download(url: String): ByteArray = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "LibreBlox/0.3 (Android)")
        try {
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private suspend fun assetBytes(id: Long): ByteArray {
        try {
            val j = JSONObject(String(download("https://assetdelivery.roblox.com/v2/assetId/$id")))
            val loc = j.optJSONArray("locations")?.optJSONObject(0)?.optString("location")
            if (!loc.isNullOrEmpty()) return download(loc)
        } catch (_: Exception) {
        }
        return download("https://assetdelivery.roblox.com/v1/asset/?id=$id")
    }

    private fun isImage(b: ByteArray) = b.size > 4 &&
        ((b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte()) || (b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte()))

    /** Shirt/Pants/Face assets are tiny XML files that point to the real image asset. */
    private suspend fun loadBitmap(id: Long, depth: Int): Bitmap? {
        val b = assetBytes(id)
        if (isImage(b)) return BitmapFactory.decodeByteArray(b, 0, b.size)
        if (depth >= 2) return null
        val txt = String(b, Charsets.ISO_8859_1)
        val m = Regex("""(?:asset/\?id=|rbxassetid://|assetId=)(\d+)""", RegexOption.IGNORE_CASE).find(txt) ?: return null
        return loadBitmap(m.groupValues[1].toLong(), depth + 1)
    }
}

/** Drag to rotate, tap to pause/resume auto-rotation. */
@Composable
fun AvatarView(outfit: Outfit, modifier: Modifier = Modifier, autoRotate: Boolean = true, initialYaw: Float = 25f) {
    val ctx = LocalContext.current
    val head = remember { AvatarMeshes.head(ctx) }
    var yaw by remember { mutableFloatStateOf(initialYaw) }
    var dragging by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(autoRotate) }
    LaunchedEffect(dragging, auto) {
        if (!dragging && auto) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                yaw += (now - last) / 1_000_000_000f * 30f
                last = now
            }
        }
    }
    Canvas(
        modifier
            .pointerInput(Unit) { detectTapGestures(onTap = { auto = !auto }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                ) { change, drag ->
                    change.consume()
                    yaw += drag.x * 0.6f
                }
            },
    ) {
        val y = yaw
        drawIntoCanvas { AvatarRenderer.render(it.nativeCanvas, size.width, size.height, y, outfit, head) }
    }
}

