package org.libreblox.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Downloads and caches clothing textures / accessory sprites for worn items. */
object AvatarTex {
    val tex = mutableStateMapOf<Long, Bitmap>()
    val sprites = mutableStateMapOf<Long, Bitmap>()
    val failed = mutableStateMapOf<Long, String>()
    private val busy = HashSet<Long>()

    suspend fun ensure(item: CatItem) {
        val id = item.id
        val slot = Wear.slot(item.assetType)
        if (slot == Wear.NONE) return
        if (tex.containsKey(id) || sprites.containsKey(id) || !busy.add(id)) return
        try {
            if (slot == Wear.ACC) {
                val url = item.thumb ?: throw IllegalStateException("нет превью")
                val b = download(url)
                BitmapFactory.decodeByteArray(b, 0, b.size)?.let { sprites[id] = it }
            } else {
                val bmp = loadBitmap(id, 0) ?: throw IllegalStateException("текстура не найдена")
                tex[id] = bmp
            }
            failed.remove(id)
        } catch (e: Exception) {
            failed[id] = e.message ?: e.toString()
        } finally {
            busy.remove(id)
        }
    }

    private suspend fun download(url: String): ByteArray = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "LibreBlox/0.3 (Android)")
        try {
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private suspend fun assetBytes(id: Long): ByteArray {
        try {
            val j = JSONObject(String(download("https://assetdelivery.roblox.com/v2/assetId/$id")))
            val loc = j.optJSONArray("locations")?.optJSONObject(0)?.optString("location")
            if (!loc.isNullOrEmpty()) return download(loc)
        } catch (_: Exception) {
        }
        return download("https://assetdelivery.roblox.com/v1/asset/?id=$id")
    }

    private fun isImage(b: ByteArray) = b.size > 4 &&
        ((b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte()) || (b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte()))

    /** Shirt/Pants/Face assets are tiny XML files that point to the real image asset. */
    private suspend fun loadBitmap(id: Long, depth: Int): Bitmap? {
        val b = assetBytes(id)
        if (isImage(b)) return BitmapFactory.decodeByteArray(b, 0, b.size)
        if (depth >= 2) return null
        val txt = String(b, Charsets.ISO_8859_1)
        val m = Regex("""(?:asset/\?id=|rbxassetid://|assetId=)(\d+)""", RegexOption.IGNORE_CASE).find(txt) ?: return null
        return loadBitmap(m.groupValues[1].toLong(), depth + 1)
    }
}

/** Drag to rotate, tap to pause/resume auto-rotation. */
@Composable
fun AvatarView(outfit: Outfit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val head = remember { AvatarMeshes.head(ctx) }
    var yaw by remember { mutableFloatStateOf(25f) }
    var dragging by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(true) }
    LaunchedEffect(dragging, auto) {
        if (!dragging && auto) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                yaw += (now - last) / 1_000_000_000f * 30f
                last = now
            }
        }
    }
    Canvas(
        modifier
            .pointerInput(Unit) { detectTapGestures(onTap = { auto = !auto }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                ) { change, drag ->
                    change.consume()
                    yaw += drag.x * 0.6f
                }
            },
    ) {
        val y = yaw
        drawIntoCanvas { AvatarRenderer.render(it.nativeCanvas, size.width, size.height, y, outfit, head) }
    }
}

private val PALETTE: List<Pair<String, Long>> = listOf(
    "Жёлтый" to 0xFFF5CD30, "Белый" to 0xFFF2F3F3, "Серый" to 0xFFA3A2A5, "Тёмно-серый" to 0xFF635F62,
    "Чёрный" to 0xFF1B2A35, "Красный" to 0xFFC4281C, "Оранжевый" to 0xFFDA8541, "Розовый" to 0xFFE9A5C6,
    "Синий" to 0xFF0D69AC, "Голубой" to 0xFF98C2DB, "Зелёный" to 0xFF287F47, "Салатовый" to 0xFF4B974B,
    "Фиолетовый" to 0xFF6B327C, "Бежевый" to 0xFFF2C28D, "Телесный" to 0xFFCC8E69, "Коричневый" to 0xFF7C5C46,
)

private val PARTS = listOf("Всё тело", "Голова", "Торс", "Руки", "Ноги")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalAvatarScreen() {
    val ctx = LocalContext.current
    val items = LocalStore.outfit()
    var part by remember { mutableIntStateOf(0) }

    LaunchedEffect(items.map { it.id }) {
        items.forEach { launch { AvatarTex.ensure(it) } }
    }

    fun texOf(slot: Int): Bitmap? =
        items.firstOrNull { Wear.slot(it.assetType) == slot }?.let { AvatarTex.tex[it.id] }

    val outfit = Outfit(
        colors = LocalStore.bodyColors.toIntArray(),
        shirt = texOf(Wear.SHIRT),
        pants = texOf(Wear.PANTS),
        tshirt = texOf(Wear.TSHIRT),
        face = texOf(Wear.FACE),
        sprites = items.filter { Wear.slot(it.assetType) == Wear.ACC }
            .mapNotNull { i -> AvatarTex.sprites[i.id]?.let { Sprite(it, Wear.attach(i.assetType)) } },
    )

    fun applyColor(argb: Int) {
        when (part) {
            0 -> LocalStore.setAllBodyColors(argb)
            1 -> LocalStore.setBodyColor(0, argb)
            2 -> LocalStore.setBodyColor(1, argb)
            3 -> { LocalStore.setBodyColor(2, argb); LocalStore.setBodyColor(3, argb) }
            else -> { LocalStore.setBodyColor(4, argb); LocalStore.setBodyColor(5, argb) }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Аватар", fontWeight = FontWeight.Bold) }) }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(
                Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                AvatarView(outfit, Modifier.fillMaxSize())
                Text(
                    "Тяни — вращать, тап — пауза",
                    Modifier.align(Alignment.BottomCenter).padding(8.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Цвет тела", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PARTS.forEachIndexed { i, n -> FilterChip(selected = part == i, onClick = { part = i }, label = { Text(n) }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PALETTE.forEach { (_, c) ->
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).background(Color(c))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                    .clickable { applyColor(c.toInt()) },
                            )
                        }
                    }
                    TextButton(onClick = { LocalStore.resetColors() }) { Text("Сбросить цвета") }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Надето (${items.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (items.isEmpty()) {
                        Text(
                            "Пока ничего. Открой «Инвентарь» → «Надеть» или «Каталог» → «Примерить».",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    items.forEach { item ->
                        val trying = LocalStore.isTryingOn(item.id)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AsyncImage(
                                model = item.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surface),
                            )
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                val err = AvatarTex.failed[item.id]
                                Text(
                                    when {
                                        err != null -> "Не загрузилась текстура: $err"
                                        trying -> "Примерка"
                                        else -> "Надето"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                )
                            }
                            if (trying) {
                                TextButton(onClick = {
                                    LocalStore.equip(item)
                                    Toast.makeText(ctx, "Забрано и надето", Toast.LENGTH_SHORT).show()
                                }) { Text("Забрать") }
                                IconButton(onClick = { LocalStore.toggleTryOn(item) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Снять примерку")
                                }
                            } else {
                                IconButton(onClick = { LocalStore.unequip(item.id) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Снять")
                                }
                            }
                        }
                    }
                    if (items.isNotEmpty()) {
                        OutlinedButton(onClick = { LocalStore.takeOffAll() }, modifier = Modifier.fillMaxWidth()) { Text("Снять всё") }
                    }
                }
            }
            Text(
                "Рубашки, штаны, футболки и лица кладутся на тело по настоящему шаблону Roblox. " +
                    "Аксессуары показываются картинкой-превью (3D-меши аксессуаров пока не загружаются).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
