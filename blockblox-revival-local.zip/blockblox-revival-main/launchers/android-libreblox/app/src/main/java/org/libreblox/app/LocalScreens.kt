package org.libreblox.app

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale

private val LocGreen = Color(0xFF00B06F)
private val LocBlue = Color(0xFF0066FF)

private fun locFmt(n: Long): String = String.format(Locale.US, "%,d", n)

/** Blue "verified" tick shown next to the name. */
@Composable
fun LocVerifiedBadge(modifier: Modifier = Modifier) {
    Icon(
        Icons.Default.CheckCircle,
        contentDescription = "Verified",
        tint = LocBlue,
        modifier = modifier.size(22.dp),
    )
}

// ------------------------------------------------------------------ catalog

private data class LocCat(val label: String, val id: Int?)

private val locCats = listOf(
    LocCat("Все", 1),
    LocCat("Аксессуары", 11),
    LocCat("Одежда", 3),
    LocCat("Части тела", 4),
    LocCat("Анимации", 12),
    LocCat("Снаряжение", 5),
    LocCat("Коллекционные", 2),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalCatalogScreen() {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Int?>(1) }
    var res by remember { mutableStateOf<Load<List<CatItem>>>(Load.Idle) }
    var job by remember { mutableStateOf<Job?>(null) }

    fun go() {
        job?.cancel()
        res = Load.Busy
        job = scope.launch {
            res = try {
                Load.Ok(Api.catalogItems(query, cat))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Load.Err(e.message ?: e.toString())
            }
        }
    }

    LaunchedEffect(cat) { go() }

    Scaffold(topBar = { TopAppBar(title = { Text("Каталог Roblox", fontWeight = FontWeight.Bold) }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Поиск предметов") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { go() }),
                trailingIcon = {
                    IconButton(onClick = { go() }) { Icon(Icons.Default.Search, contentDescription = "Искать") }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                locCats.forEach { c ->
                    FilterChip(selected = cat == c.id, onClick = { cat = c.id }, label = { Text(c.label) })
                }
            }
            Box(Modifier.fillMaxSize()) {
                when (val s = res) {
                    Load.Idle, Load.Busy -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    is Load.Err -> Column(
                        Modifier.align(Alignment.Center).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text("Не удалось загрузить каталог", fontWeight = FontWeight.SemiBold)
                        Text(s.msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = { go() }) { Text("Повторить") }
                    }
                    is Load.Ok -> if (s.v.isEmpty()) {
                        Text("Ничего не найдено", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        LazyColumn(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(s.v) { LocCatalogRow(it) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LocThumb(url: String?) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface),
    )
}

@Composable
private fun LocCatalogRow(item: CatItem) {
    val ctx = LocalContext.current
    val has = LocalStore.owns(item.id)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LocThumb(item.thumb)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val pr = item.price
                val priceText = when {
                    pr == null -> "Не продаётся"
                    pr == 0L -> "Бесплатно"
                    else -> "R$ ${locFmt(pr)}"
                }
                Text(
                    listOf(item.creator, priceText).filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (has) {
                    Text("✓ В инвентаре", color = LocGreen, fontWeight = FontWeight.SemiBold)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            LocalStore.give(item)
                            Toast.makeText(ctx, "Добавлено в инвентарь", Toast.LENGTH_SHORT).show()
                        }) { Text("Забрать") }
                        val p = item.price
                        if (p != null && p > 0) {
                            OutlinedButton(onClick = {
                                val ok = LocalStore.buy(item)
                                Toast.makeText(ctx, if (ok) "Куплено" else "Не хватает R$", Toast.LENGTH_SHORT).show()
                            }) { Text("R$ ${locFmt(p)}") }
                        }
                    }
                    val trying = LocalStore.isTryingOn(item.id)
                    TextButton(onClick = {
                        if (!LocalStore.toggleTryOn(item)) {
                            Toast.makeText(ctx, "Этот тип предмета пока нельзя примерить", Toast.LENGTH_SHORT).show()
                        } else if (!trying) {
                            Toast.makeText(ctx, "Смотри вкладку «Аватар»", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text(if (trying) "Снять примерку" else "Примерить") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ inventory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalInventoryScreen() {
    Scaffold(topBar = { TopAppBar(title = { Text("Инвентарь (${LocalStore.owned.size})", fontWeight = FontWeight.Bold) }) }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (LocalStore.owned.isEmpty()) {
                Text(
                    "Пока пусто. Открой «Каталог» и нажми «Забрать» у любого предмета.",
                    Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(LocalStore.owned.toList()) { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(
                                Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                LocThumb(item.thumb)
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    if (item.creator.isNotEmpty()) {
                                        Text(
                                            item.creator,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                                val ctx = LocalContext.current
                                if (LocalStore.isWearable(item)) {
                                    TextButton(onClick = { LocalStore.toggleEquip(item) }) {
                                        Text(if (LocalStore.isEquipped(item.id)) "Снять" else "Надеть")
                                    }
                                } else {
                                    TextButton(onClick = {
                                        Toast.makeText(ctx, "Этот тип предмета пока нельзя надеть", Toast.LENGTH_SHORT).show()
                                    }) { Text("—") }
                                }
                                IconButton(onClick = { LocalStore.remove(item.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Убрать")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
